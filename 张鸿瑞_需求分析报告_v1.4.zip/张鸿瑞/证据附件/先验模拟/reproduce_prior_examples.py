"""Recompute synthetic examples only. No application, network or database access.

Run with Python 3: python reproduce_prior_examples.py
No third-party dependencies. This cannot establish actual product performance.
"""
from pathlib import Path
import csv
import json
import math

ROOT = Path(__file__).resolve().parent

def rows(name):
    with (ROOT / name).open(encoding='utf-8-sig', newline='') as handle:
        result = list(csv.DictReader(handle))
    assert result and all(r['synthetic'] == 'True' for r in result)
    return result

def p95(values):
    return sorted(values)[math.ceil(.95 * len(values)) - 1]

expected = json.loads((ROOT / '模拟计算摘要.json').read_text(encoding='utf-8'))
assert expected['synthetic'] and not expected['real_world_test_executed']
request_rows = rows('NF01_构造请求记录.csv')
success = [int(r['duration_ms']) for r in request_rows if r['outcome'] == 'success']
request_result = {'count': len(request_rows), 'success': len(success),
                  'failures': len(request_rows) - len(success),
                  'success_percent': 100 * len(success) / len(request_rows),
                  'successful_request_p95_ms': p95(success),
                  'p95_rank': math.ceil(.95 * len(success))}
for key, value in request_result.items():
    assert expected['NF01'][key] == value, (key, value)
stages = rows('NF01_构造阶段耗时.csv')
assert len(stages) == 30
stage_result = {}
for key in ('acceptance_ms', 'first_chart_ms', 'cached_completion_ms'):
    stage_result[key] = p95([int(r[key]) for r in stages])
    assert expected['NF01'][key + '_p95_ms'] == stage_result[key]
usability = rows('NF06_虚拟任务记录.csv')
usability_success = 0
for row in usability:
    calculated = (row['completed'] == 'True' and row['assisted'] == 'False'
                  and int(row['elapsed_seconds']) <= 180)
    assert calculated == (row['expected_success'] == 'True')
    usability_success += calculated
assert len(usability) == 20 and usability_success == expected['NF06']['successful'] == 18
materials = rows('NF11_构造标签.csv')
confusion = {'TP': 0, 'FP': 0, 'FN': 0, 'TN': 0}
for row in materials:
    valid = row['assumed_valid_label'] == 'True'
    retained = row['assumed_system_retained'] == 'True'
    confusion[('T' if valid == retained else 'F') + ('P' if retained else 'N')] += 1
assert len(materials) == 100 and confusion == expected['NF11']['assumed_labels']
precision = 100 * confusion['TP'] / (confusion['TP'] + confusion['FP'])
assert precision == expected['NF11']['precision_percent']
claims = rows('NF11_构造断言标签.csv')
unsupported = sum(r['assumed_supported'] == 'False' for r in claims)
assert len(claims) == 100 and unsupported == expected['NF11']['unsupported'] == 3
nf10 = expected['NF10']
restore = nf10['assumed_size_MiB'] / nf10['assumed_throughput_MiB_s'] + nf10['assumed_extra_seconds']
assert restore == nf10['estimated_restore_seconds'] == 282.4
assert 10240 / 5 + 180 == nf10['counterexample_restore_seconds'] == 2228
for model in expected['queue_models']:
    rate = model['arrival_per_second']
    service = model['assumed_service_seconds']
    if rate * service >= 1:
        assert model['model_p95_seconds'] is None
    else:
        estimate = model['assumed_fixed_overhead_seconds'] + math.log(20) / (1 / service - rate)
        assert math.isclose(estimate, model['model_p95_seconds'])
# Fail-side examples ensure the acceptance rules distinguish opposite outcomes.
assert 100 * 17 / 20 < 90
assert 10240 / 5 + 180 > 30 * 60
assert 100 * 76 / 86 < 90
assert 100 * 6 / 100 > 5
assert 28 / 5600 < .01 and p95(success) <= 2000
print(json.dumps({'evidence_type': 'synthetic arithmetic only',
    'calculation_checks': 'passed', 'product_performance_verified': False,
    'request_examples': request_result, 'stage_p95_ms': stage_result,
    'virtual_task_success': usability_success, 'confusion_matrix': confusion,
    'synthetic_precision_percent': precision, 'synthetic_unsupported_count': unsupported,
    'estimated_restore_seconds': restore}, ensure_ascii=False, indent=2))
